// ListNode.java

public class ApplianceNode
{
   protected Appliance data;
   protected ApplianceNode next;

   /**
    * sets data and what the next node is for the appliance
    *
    * @param d
    */
   public ApplianceNode(Appliance d)
   {
      data = d;
      next = null;
   }  // constructor
}  // class ShortNode

